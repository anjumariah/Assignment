import scrapy


class NewprojectSpider(scrapy.Spider):
    name = 'newproject'
    allowed_domains = ['https://carbon38.com/']
    start_urls = ['http://https://carbon38.com//'
                  'https://carbon38.com/collections/tops'
                  ]

    def parse(self, response,brand,product_name,price):
        brand = response.xpath('span.product-detail-label::text').extract()
        product_name = response.xpath('h1.title::text').extract()
        price=response.xpath('span.current-price theme-money::text').extract()

        row_data = zip(brand,product_name,price)

        for item in row_data:
            scraped_info = {
                'page': response.url,
                'brand': item[0],
                'product_name': item[1],
                'price': item[2],

            }
            yield scraped_info

